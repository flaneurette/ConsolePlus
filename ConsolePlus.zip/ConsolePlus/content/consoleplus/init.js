function launchconsoleplus()
{
   window.open("chrome://consoleplus/content/cplus.xul", "Console+", "chrome,centerscreen,width=960,height=760,resizable,scrollbars=yes,status=1");
}